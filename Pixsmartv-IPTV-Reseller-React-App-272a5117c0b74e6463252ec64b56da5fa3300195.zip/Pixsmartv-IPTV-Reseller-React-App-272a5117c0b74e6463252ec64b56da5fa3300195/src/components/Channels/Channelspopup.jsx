import Channels from './Channels'
import React from 'react'
import './Channelspopup.css'

const Channelspopup = () => {
  return (
    <div className="channels-popup-section">
        <Channels/>
    </div>
    
  )
}

export default Channelspopup