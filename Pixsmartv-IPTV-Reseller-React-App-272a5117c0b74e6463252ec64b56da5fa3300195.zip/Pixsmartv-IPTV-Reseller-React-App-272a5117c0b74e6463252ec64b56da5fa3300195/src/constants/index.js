import images from './channels'
import movies from './movies'
import revs from './reviewsimg'

export {images, movies, revs}

